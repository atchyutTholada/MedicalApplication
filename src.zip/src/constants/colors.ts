export const COLORS = {
  primary: '#4A90E2',
  white: '#FFFFFF',
  black: '#000000',
  gray: '#808080',
  blue:'#13CAD6'
};
