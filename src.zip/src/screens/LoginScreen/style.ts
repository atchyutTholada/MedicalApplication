import { StyleSheet, Dimensions } from 'react-native';

const { width } = Dimensions.get('window');

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },
  header: {
    backgroundColor: '#33E4DB',
    paddingVertical: 20,
    alignItems: 'center',
  },
  headerText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  content: {
    paddingHorizontal: 20,
    marginTop: 20,
  },
  welcomeText: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#33E4DB',
    textAlign: 'center',
  },
  description: {
    fontSize: 14,
    color: '#607D8B',
    textAlign: 'center',
    marginVertical: 10,
  },
  label: {
    fontSize: 14,
    color: '#607D8B',
    marginTop: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: '#B0BEC5',
    borderRadius: 8,
    padding: 10,
    marginTop: 5,
    color: '#000000',
  },
  passwordContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  showPassword: {
    color: '#607D8B',
    marginLeft: 10,
  },
  forgotPassword: {
    color: '#33E4DB',
    textAlign: 'right',
    marginTop: 10,
  },
  loginButton: {
    backgroundColor: '#33E4DB',
    paddingVertical: 15,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 20,
  },
  loginButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  orText: {
    textAlign: 'center',
    color: '#607D8B',
    marginVertical: 20,
  },
  socialIcons: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginBottom: 20,
  },
  iconCircle: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: '#E0F7FA',
    alignItems: 'center',
    justifyContent: 'center',
    marginHorizontal: 10,
  },
  signUpText: {
    textAlign: 'center',
    color: '#607D8B',
  },
  signUpLink: {
    color: '#33E4DB',
    fontWeight: 'bold',
  },
});

export default styles;
